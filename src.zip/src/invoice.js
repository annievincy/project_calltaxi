import React, { Component } from 'react';
import logo from './logo.svg';

import './App.css';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import Fares from './fares';
class invoice extends Component {
	constructor(props){
  super(props);
  this.state={
  
  }
	}
  render() {
    
return (
      <div>
        <MuiThemeProvider>
          <div>
          <AppBar/>

		   <p>How do I get the invoice for my ride?</p>
       

       


		   


			 
         </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
 margin: 15,
};
export default invoice;

     