import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import logo from './logo.svg';
import './register.css';
import TextField from 'material-ui/TextField';
import axios from 'axios';
class Register extends Component {
  constructor(props){
    super(props);
    this.state={
      first_name:'',
      last_name:'',
      email:'',
      password:''
    }
  }
  render() {
    return (
	 
      <div>
        <MuiThemeProvider>
          <div>
          <AppBar
             title="Register"
           />
           <TextField
             hintText="Enter your Name"
             floatingLabelText="Name"
             onChange = {(event,newValue) => this.setState({name:newValue})}
             />
           <br/>
           <TextField
             hintText="Enter your Email"
             floatingLabelText="Email"
             onChange = {(event,newValue) => this.setState({email:newValue})}
             />
           <br/>
		   <TextField
             hintText="Enter your UserName"
             floatingLabelText="UserName"
             onChange = {(event,newValue) => this.setState({user_name:newValue})}
             />
           <br/>
           <TextField
		    type="password"
             hintText="Enter your Password"
             floatingLabelText="Password"
             onChange = {(event,newValue) => this.setState({password:newValue})}
             />
           <br/>
           <TextField
              type="password"
             hintText="Enter your Correct Password"
             floatingLabelText="Confirm Password"
             onChange = {(event,newValue) => this.setState({confirm_password:newValue})}
             />
           <br/>
           <TextField
           
             hintText="Enter your Phone Number"
             floatingLabelText="Phone_no"
             onChange = {(event,newValue) => this.setState({phone_no:newValue})}
             />
           <br/>
		  <form id ='register.js' action='register.php' onSubmit={this.handleSubmit}>
				<button type="submit">SignUp</button>
			</form>
          </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
  margin: 15,
};
export default Register;