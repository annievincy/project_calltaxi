import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Emergency from './emergency';
import Login from './login';
import Payment from './payment';
import Register from './register';
import Support from './support';

class App extends Component {
   render() {
      return (
         <Router>
            <div>
				<ul>
                  <li><Link to={'/'}>Login</Link></li>
                        <li><Link to={'/Register'}>Register</Link></li>
							<li><Link to={'/Emergency'}>Emergency</Link></li>
								<li><Link to={'/Payment'}>Payment</Link></li>
									<li><Link to={'/Support'}>Support</Link></li>
				</ul>
               <hr />
               
               <Switch>
                  <Route exact path='/' component={Login} />
					<Route exact path='/Emergency' component={Emergency} />
						<Route exact path='/Payment' component={Payment} />
							<Route exact path='/Register' component={Register} />
								<Route exact path='/Support' component={Support} />

               </Switch>
            </div>
         </Router>
      );
   }
}
