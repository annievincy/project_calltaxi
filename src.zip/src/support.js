import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import logo from './logo.svg';
import TextField from 'material-ui/TextField';
import axios from 'axios';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import FAQs from './FAQ';
import PaymentOptions from './payopt';
import FaresandCharges from './fares';
class Support extends Component {
  constructor(props){
    super(props);
    this.state={
      
    }
  }
  render() {
    return (
      <Router>
      <div>
        <MuiThemeProvider>
          <div>
          
             How can we help?<br/>
          <input type="text" name="text"/>
               <RaisedButton label= "Search" primary={true} style={style} onClick={(event) => this.handleClick(event)}/><br/>
                 Browse topics<br/>
                 <br/>
                 <ul>
                    <li><Link to={'/FAQs'}>Frequently asked questions</Link></li>
                    <li><Link to ={'/PaymentOptions'}>Payment Options</Link></li>
                    <li><Link to={'/FaresandCharges'}>Fares & Charges</Link></li>
                 </ul>
                    <hr />
                   <Switch>
                         <Route exact path='/FAQs' component={FAQs} />
                         <Route exact path='/PaymentOptions' component={PaymentOptions} />
                        <Route exact path='/FaresandCharges' component={FaresandCharges} />
                   </Switch>


                     

          </div>

         </MuiThemeProvider>
      </div>
      </Router>
    );
  }
}
const style = {
  margin: 15,
};
export default Support;