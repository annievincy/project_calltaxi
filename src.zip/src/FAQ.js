import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import logo from './logo.svg';
import TextField from 'material-ui/TextField';
import axios from 'axios';
import Invoice from './invoice';
class FAQ extends Component {
  constructor(props){
    super(props);
    this.state={
      
    }
  }
  render() {
    return (
      <div>
        <MuiThemeProvider>
          <div>
          <AppBar title="FAQs"
             />
<ul>
          <li><Link to={'/Invoice'}>How do I get the Invoice for my ride?</Link></li>
</ul>
<Switch>
         <Route exact path='/Invoice' component={Invoice} />
         </Switch>

            


          </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
  margin: 15,
};
export default FAQ;